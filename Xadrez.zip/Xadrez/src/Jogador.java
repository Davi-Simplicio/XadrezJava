import java.util.ArrayList;

public class Jogador {
    private String nome="";
    private String cor;
    private String senha;
    private double pontos;
    private ArrayList<Peca> peca;

    public boolean moverPeca( Peca peca,Posicao posicao){
        return true;
    }

    public void desistir(){

    }
    public boolean proporEmpate(Jogador jogador){
        return true;
    }
}