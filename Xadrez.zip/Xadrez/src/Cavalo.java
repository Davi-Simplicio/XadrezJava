import java.util.ArrayList;

public class Cavalo extends Peca{
    @Override
    public ArrayList<Posicao> possiveisMovimentos(Tabuleiro tabuleiro) {
        return null;
    }
}
