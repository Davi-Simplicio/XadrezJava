import java.util.ArrayList;

public class Torre extends Peca{

    private boolean primeiroMovimento;
    @Override
    public ArrayList<Posicao> possiveisMovimentos(Tabuleiro tabuleiro) {
        return null;
    }
}
