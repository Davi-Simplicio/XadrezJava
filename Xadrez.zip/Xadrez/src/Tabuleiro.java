import java.util.ArrayList;

public class Tabuleiro {
    private  ArrayList<Posicao> posicoes;

    public ArrayList<Posicao> getPosicoes() {
        return posicoes;
    }

    public void removerPeca(Posicao posicao){

    }
}
